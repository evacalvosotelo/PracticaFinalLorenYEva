INSERT INTO usuario (email, credenciales,nombre) VALUES ('admin@e.m', 'Basic YWRtaW5AZS5tOmFkbWlu','Lorenzo');
INSERT INTO usuario (email, credenciales,nombre) VALUES ('boss@e.m', 'Basic Ym9zc0BlLm06Ym9z','Eva');
INSERT INTO usuario (email, credenciales,nombre) VALUES ('user@e.m', 'Basic dXNlckBlLm06dXNlcg==','Alberto');