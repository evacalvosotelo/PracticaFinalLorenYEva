let nombre = localStorage.getItem('nombre');
let contra = localStorage.getItem('contra');
const username = nombre
const password = contra
const miFuncion = () => {
    console.log("Hola")
}
//const displayContactos = (lista)=>{
//   let div = document.getElementById("div-chats")
//   div.innerHTML = "";
//   lista.forEach(element => {
//       elemento = '<div class = "div-chat" onclick="miFuncion()"><div class = "imagen-perfil"></div><img src="" alt="" ><label for="" class = "text-perfil">'+element.nombre+'</label></div><div class = "separador"></div>'
//       div.innerHTML = div.innerHTML + elemento;
//   }); 
//}
// Queremos que un grupo se cree si no hay todavía ninguno, y un usuario le manda un mensaje a otro con el que no ha hablado todavía
const displayMensajes = (lista) => {
    let div = document.getElementById("div-conversation-2")
    div.innerHTML = "";
    lista.forEach(element => {
        lado = "";
        if (element.usuario.email == username){
            lado = "right"
        }
        else{
            lado = "left";
        }
        let fechaHora = element.fecha;
        let fecha = new Date(fechaHora);
        let horas = fecha.getHours();
        let minutos = fecha.getMinutes();
        let horaMinuto = horas.toString().padStart(2, '0') + ':' + minutos.toString().padStart(2, '0');
        if (element.mensaje.substring(10) == "https://ww"){
            elemento = '<div class = "div-mensaje-'+lado+'"><label for="" class = "usuario">'+(element.usuario.email).split("@")[0]+'</label><iframe width="420" height="315" src='+element.mensaje+'></iframe><label for="" class = "hora">'+horaMinuto+'</label></div>'
        }else{
        elemento = '<div class = "div-mensaje-'+lado+'"><label for="" class = "usuario">'+(element.usuario.email).split("@")[0]+'</label><label for="" class = "mensaje">'+element.mensaje+'</label><label for="" class = "hora">'+horaMinuto+'</label></div>'
        }
        div.innerHTML = div.innerHTML + elemento;
    });
}


const credentials = `${username}:${password}`;
const encodedCredentials = btoa(credentials);

const headers = {
  'Authorization': `Basic ${encodedCredentials}`,
  'Content-Type': 'application/json'
};
const postMensajes = async (mensaje) => {
    let request = await fetch("http://localhost:8080/api/mensajes/manda",{
        method:"POST",
        headers: headers,
        body: JSON.stringify({
          "id":1,
          "mensaje":mensaje,
          "fecha":12
        })
    })
}
const getMensajes = async () => {
    let request = await fetch("http://localhost:8080/api/mensajes",{
        method:"GET",
    })
    if(request.status == 200){
        let data = await request.json();
        displayMensajes(data);
    }
}

document.getElementById("boton-send").addEventListener("click",()=>{
    let mensaje = document.getElementById("input-mensaje").value;
    if (mensaje != ""){
        postMensajes(mensaje)
    }
})
const enviarMensaje = () => {
    let mensaje = document.getElementById("input-mensaje").value;
    if (mensaje != ""){
        postMensajes(mensaje)   
        document.getElementById("input-mensaje").value = "";  
    }   
    let myDiv = document.getElementById("div-conversation-2");
        myDiv.scrollTop = myDiv.scrollHeight; 
}
const getUsuarios = async ()=>{
    let request = await fetch("http://localhost:8080/api/usuarios",{
        method:"GET",
        headers: headers,
    })
    if(request.status == 200){
        let data = await request.json();
    }
}
getUsuarios();
getMensajes();
let contador = 0;
let myDiv = document.getElementById("div-conversation-2");
myDiv.scrollTop = myDiv.scrollHeight
setInterval(function() {
    getUsuarios();
    getMensajes();
    if (contador == 0){
        let myDiv = document.getElementById("div-conversation-2");
        myDiv.scrollTop = myDiv.scrollHeight
        contador++
    }
}, 100);

