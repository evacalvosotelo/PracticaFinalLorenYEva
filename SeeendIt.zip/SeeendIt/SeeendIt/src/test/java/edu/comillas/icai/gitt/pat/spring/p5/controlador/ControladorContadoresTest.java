package edu.comillas.icai.gitt.pat.spring.p5.controlador;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@AutoConfigureTestDatabase
class ControladorContadoresTest {
    private final TestRestTemplate restTemplate = new TestRestTemplate("admin@e.m", "admin");

    //TODO Incluir OTROS casos de prueba (2xx y 4xx) diferentes a los de abajo

    @Test
    public void contadorExistenteTest() {
        // Given ...
        String contador = "{\"nombre\":\"visitas\",\"valor\":0}";
        String contador2 = "{\"nombre\":\"visitas\",\"valor\":1}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        //TEST END-TO-END con este template       
        restTemplate.exchange(
                "http://localhost:8080/api/contadores", HttpMethod.POST,
                new HttpEntity<>(contador, headers), String.class);
        // When ...
        ResponseEntity<String> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores/visitas",
                HttpMethod.GET, HttpEntity.EMPTY, String.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        Assertions.assertEquals(contador, response.getBody());
    }

    @Test
    public void contadorNoExistenteTest() {
        // When ...
        ResponseEntity<Void> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores/no-existo",
                HttpMethod.GET, HttpEntity.EMPTY, Void.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    //Caso de prueba: Contador con Valor Válido, 201: CREATED
    @Test
    public void contadorValido(){
        String contador = "{\"nombre\":\"pruebas\",\"valor\":10}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity <String> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores", HttpMethod.POST,
                new HttpEntity<>(contador, headers), String.class);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
        Assertions.assertEquals(contador, response.getBody());
    }

    //Caso de prueba: contador No valido,  400
    @Test
    public void contadorNoValido(){
        String contador = "{\"nombre\":\"pruebas\",\"valor\":alba}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        //When...
        ResponseEntity <String> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores", HttpMethod.POST,
                new HttpEntity<>(contador, headers), String.class);
        //Then...
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    //Caso de prueba: INCREMENTO VALIDO, 200
    @Test
    public void incrementoValido(){
        //Creamos la info que le queremos pasar
        String contador = "{\"nombre\":\"pruebas\",\"valor\":10}";
        String expected = "{\"nombre\":\"pruebas\",\"valor\":45}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        //Hacemos el post de lo anterior
        restTemplate.exchange(
                "http://localhost:8080/api/contadores", HttpMethod.POST,
                new HttpEntity<>(contador, headers), String.class);

        //When...
        ResponseEntity<String> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores/pruebas/incremento/35",
                HttpMethod.PUT, HttpEntity.EMPTY, String.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(expected, response.getBody());
    }

    //Caso de prueba: INCREMENTO NO VALIDO, 400
    @Test
    public void incrementoNoValido(){
        //Creamos la info que le queremos pasar
        String contador = "{\"nombre\":\"pruebas\",\"valor\":10}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        //Hacemos el post de lo anterior
        restTemplate.exchange(
                "http://localhost:8080/api/contadores", HttpMethod.POST,
                new HttpEntity<>(contador, headers), String.class);

        //When...
        ResponseEntity<Void> response = restTemplate.exchange(
                "http://localhost:8080/api/contadores/pruebas/incremento/alba",
                HttpMethod.PUT, HttpEntity.EMPTY, Void.class);

        //Then...
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    

}