PRÁCTICA 5: Testing y persistencia de una aplicación
-------------------------------------------------------------

TESTING

Se han creado 4 tests funcionales adicionales, siendo estos:

1. ContadorValido (201): 

Se comprueba que el contador no tiene errores en sus parámetros de entrada, y se devuelve la respuesta HTTP 201 (Created) para confirmar que se ha creado adecuadamente.

2. ContadorNoValido(400): 

Se comprueba que el contador no podrá ser creado si tiene errores en sus parámetro de entrada de "valor". 
Si este parámetro no es de tipo Long, NO se creará el contador y se devolverá la respuesta HTTP 400 (Bad Request) para indicar que el formato es erróneo.

3. IncrementoValido(200): 

Se comprueba que el valor del incremento tiene el formato adecuado (un incremento numérico). Se devuelve la respuesta HTTP 200 para indicar que se ha incrementado exitosamente.

4. IncrementoNoValido(400): 

Si el valor del parámetro del incremento no es válido (por ejemplo, una cadena de caracteres) el contador NO se incrementará y se devolverá la respuesta HTTP 400 para indicarlo.
-------------------------------------------------------------

PERSISTENCIA

Se han completado los "ToDo's" de la lista proporcionada.