package edu.comillas.icai.gitt.pat.spring.p5.entidad;

import com.fasterxml.jackson.annotation.JsonIgnore;


import jakarta.persistence.*;



import java.sql.Timestamp;


@Entity
public class Mensaje {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    public Long id;

    
    @ManyToOne
    public Usuario usuario;
    
    @Column(nullable = false,unique = false)
    public String mensaje;
    @Column(nullable = false)
    public Timestamp fecha;

    // Constructor, getters, setters, etc.
}

