package edu.comillas.icai.gitt.pat.spring.p5.repositorio;

import edu.comillas.icai.gitt.pat.spring.p5.entidad.Contador;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import edu.comillas.icai.gitt.pat.spring.p5.entidad.Mensaje;


import java.util.List;

public interface RepositorioMensaje extends CrudRepository<Mensaje,Long>{
    public List<Mensaje> findAll();

    //@Query("SELECT m.* from m Mensaje, u Usuario where u.nombre = :nombre")
    //public List<Mensaje> getMensajesFromUsuario(String nombre);
}
