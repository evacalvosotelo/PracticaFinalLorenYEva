package edu.comillas.icai.gitt.pat.spring.p5.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.comillas.icai.gitt.pat.spring.p5.repositorio.RepoGrupo;



@Service
public class ServicioGrupo {
    
    @Autowired
    RepoGrupo repositorioGrupo;
    
}
