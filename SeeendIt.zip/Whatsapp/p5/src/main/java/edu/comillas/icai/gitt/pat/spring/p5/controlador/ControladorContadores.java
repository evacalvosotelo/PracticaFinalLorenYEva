package edu.comillas.icai.gitt.pat.spring.p5.controlador;

import edu.comillas.icai.gitt.pat.spring.p5.entidad.Contador;
import edu.comillas.icai.gitt.pat.spring.p5.entidad.Usuario;
import edu.comillas.icai.gitt.pat.spring.p5.repositorio.RepoContador;
import edu.comillas.icai.gitt.pat.spring.p5.repositorio.RepoUsuario;
import edu.comillas.icai.gitt.pat.spring.p5.servicio.ServicioMensajes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import edu.comillas.icai.gitt.pat.spring.p5.entidad.Mensaje;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.time.Instant;


@RestController
public class ControladorContadores {
    

    @Autowired
    ServicioMensajes servicioMensajes;
    @Autowired
    RepoUsuario repoUsuarios;
//
    @GetMapping("/api/usuarios")
    public List<Usuario> getUsuarios(@RequestHeader("Authorization") String credenciales){
        Usuario user = servicioMensajes.autentica(credenciales);
        List<Usuario> usuarios = repoUsuarios.findAll();
        usuarios.remove(user);
        return usuarios;
    }
    @GetMapping("/api/all/usuarios")
    public Iterable<Usuario> getAllUsuarios(){
        Iterable<Usuario> usuarios = repoUsuarios.findAll();
        return usuarios;
    }

    @DeleteMapping("/api/mensajes")
    public void delteMensajes(){
        servicioMensajes.deleteAll();
    }
    @PostMapping("/api/register")
    public void register(@RequestBody Usuario user){
        repoUsuarios.save(user);
    }
    @GetMapping("/api/mensajes")
    public List<Mensaje> getMensajes(){

        // Nos autenticamos, para verificar que somos el usuario que decimos ser
        //Usuario user = servicioContadores.autentica(credenciales);
        // Cogemos todos los mensajes del superchat
        List<Mensaje> mensajes = servicioMensajes.getMensajes();
        
        return mensajes;
    }
    @PostMapping("/api/mensajes/manda")
    @ResponseStatus(HttpStatus.CREATED)
    public Mensaje postMensaje(@RequestBody Mensaje mensaje,@RequestHeader("Authorization") String credenciales){
        Usuario user = servicioMensajes.autentica(credenciales);
        mensaje.usuario = user;
        mensaje.fecha = Timestamp.from(Instant.now());
        servicioMensajes.save(mensaje);
        return mensaje;
    }



}

