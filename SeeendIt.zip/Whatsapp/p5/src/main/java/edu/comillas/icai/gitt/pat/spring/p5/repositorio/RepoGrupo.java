package edu.comillas.icai.gitt.pat.spring.p5.repositorio;

import org.springframework.data.repository.CrudRepository;

import edu.comillas.icai.gitt.pat.spring.p5.entidad.Grupo;

public interface RepoGrupo extends CrudRepository<Grupo, Long>{
    Grupo save(Grupo grupo);
}
