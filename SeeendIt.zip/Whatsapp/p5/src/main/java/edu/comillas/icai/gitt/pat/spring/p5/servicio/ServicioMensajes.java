package edu.comillas.icai.gitt.pat.spring.p5.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import edu.comillas.icai.gitt.pat.spring.p5.repositorio.RepoUsuario;
import edu.comillas.icai.gitt.pat.spring.p5.repositorio.RepositorioMensaje;
import java.util.ArrayList;
import java.util.List;

//import edu.comillas.icai.gitt.pat.spring.p5.entidad.Grupo;
import edu.comillas.icai.gitt.pat.spring.p5.entidad.Mensaje;
import edu.comillas.icai.gitt.pat.spring.p5.entidad.Usuario;


@Service
public class ServicioMensajes {
    @Autowired
    RepositorioMensaje repositorioMensajes;
    @Autowired
    RepositorioMensaje repositorioGrupo;
    @Autowired
    RepoUsuario repositorioUsuario;
    // Hemos pensado en hacer un grupo por cada dos usuarios

    //public List<Mensaje> getMensajesFromUsuario(Usuario usuario){
    //    String nombreDeUsuario = "";
    //    nombreDeUsuario = usuario.getNombre(); 
    //    return repositorioMensajes.getMensajesFromUsuario(nombreDeUsuario);
    //}
    public Usuario autentica(String credenciales) {
        Usuario usuario = repositorioUsuario.findByCredenciales(credenciales);
        //Usuario usuario2 = repoUsuario.findByEmail(usuario.email);
        if(usuario == null){
            // Si no encuentra a ningún usuario con dichas credenciales lanza un status de no autorizado
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }

        // Si no devulve el usuario
        return usuario;
    }
    public List<Mensaje> getMensajes(){
        return repositorioMensajes.findAll();
    }
    public Mensaje postMensaje(Mensaje mensaje){
        repositorioMensajes.save(mensaje);
        return mensaje;
    }
    public void deleteAll(){
        repositorioMensajes.deleteAll();
    }
    public void save(Mensaje mensaje){
        repositorioMensajes.save(mensaje);
    }
    //public Grupo postGrupo(){
    //    return new Grupo();
    //}

}
